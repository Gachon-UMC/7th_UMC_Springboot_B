package com.umc.workbook_zero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkbookZeroApplicationTests {

	@Test
	void contextLoads() {
	}

}
