package umc.study.domain.enums;

public enum Role {
    ADMIN, USER
}
