package umc.study.domain.enums;

public enum DelYN {
    DELETED, NOT_DELETED
}
