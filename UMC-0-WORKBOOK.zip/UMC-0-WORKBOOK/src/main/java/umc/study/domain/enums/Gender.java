package umc.study.domain.enums;

public enum Gender {
    MALE, FEMALE
}
