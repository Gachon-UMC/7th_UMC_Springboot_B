package umc.study.domain.enums;

public enum RequiredYN {
    REQUIRED, OPTIONAL
}
