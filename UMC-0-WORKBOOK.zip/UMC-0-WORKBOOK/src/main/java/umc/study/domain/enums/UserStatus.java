package umc.study.domain.enums;

public enum UserStatus {
    ACTIVE, INACTIVE
}
