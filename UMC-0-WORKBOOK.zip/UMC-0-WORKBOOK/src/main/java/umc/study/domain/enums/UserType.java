package umc.study.domain.enums;

public enum UserType {
    STORE_OWNER, GENERAL_USER
}
