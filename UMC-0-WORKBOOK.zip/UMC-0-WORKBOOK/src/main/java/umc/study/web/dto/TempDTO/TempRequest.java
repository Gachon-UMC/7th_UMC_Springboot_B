package umc.study.web.dto.TempDTO;

public class TempRequest {
}
