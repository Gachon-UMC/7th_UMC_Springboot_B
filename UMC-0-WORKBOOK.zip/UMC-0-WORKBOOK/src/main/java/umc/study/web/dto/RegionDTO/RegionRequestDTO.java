package umc.study.web.dto.RegionDTO;

public class RegionRequestDTO {

    private String name;
}
