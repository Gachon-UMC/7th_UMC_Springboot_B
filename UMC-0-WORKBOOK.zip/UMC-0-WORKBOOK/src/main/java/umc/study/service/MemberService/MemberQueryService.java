package umc.study.service.MemberService;

public interface MemberQueryService {
}
