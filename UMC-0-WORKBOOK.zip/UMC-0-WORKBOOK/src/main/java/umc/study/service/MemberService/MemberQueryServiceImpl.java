package umc.study.service.MemberService;

public class MemberQueryServiceImpl {
}
