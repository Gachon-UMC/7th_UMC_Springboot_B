package umc.study.service.TempService;

public class TempCommandServiceImpl {
}
