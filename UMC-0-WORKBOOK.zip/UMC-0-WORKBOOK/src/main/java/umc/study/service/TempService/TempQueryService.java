package umc.study.service.TempService;

public interface TempQueryService {

    void CheckFlag(Integer flag);
}
