package umc.study.service.MissionService;

public interface MissionQueryService {
}
