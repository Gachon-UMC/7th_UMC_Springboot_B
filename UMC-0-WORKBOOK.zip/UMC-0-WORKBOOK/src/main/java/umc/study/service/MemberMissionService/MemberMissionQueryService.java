package umc.study.service.MemberMissionService;

public interface MemberMissionQueryService {
}
