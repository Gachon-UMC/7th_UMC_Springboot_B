package umc.study.service.MemberMissionService;

public class MemberMissionQueryServiceImpl implements MemberMissionQueryService{
}
