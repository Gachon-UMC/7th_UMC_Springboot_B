package umc.study.service.MissionService;

public class MissionQueryServiceImpl {
}
